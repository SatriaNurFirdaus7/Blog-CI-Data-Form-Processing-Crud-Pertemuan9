# Pertemuan8_database_CI
Tugas Praktikum Pertemuan 8
